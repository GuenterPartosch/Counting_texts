# multizaehlen (Overview)

* [multizaehlen.exe](https://github.com/GuenterPartosch/Counting_texts/blob/master/multizaehlen/multizaehlen.exe "Windows executables of multizaehlen.py"): 
  Windows executables of multizaehlen.py
* [multizaehlen.man](https://github.com/GuenterPartosch/Counting_texts/blob/master/multizaehlen/multizaehlen.man "manpage"): 
  manpage file of zaehlen (with call and options)
* [multizaehlen.py](https://github.com/GuenterPartosch/Counting_texts/blob/master/multizaehlen/multizaehlen.py "Python program"): 
  Python program
* [multizaehlen_ini.py](https://github.com/GuenterPartosch/Counting_texts/blob/master/multizaehlen/multizaehlen_ini.py "configuration file for multizaehlen.py"): 
  configuration file for multizaehlen.py
* [multizaehlen-dependencies.txt](https://github.com/GuenterPartosch/Counting_texts/blob/master/multizaehlen/multizaehlen-dependencies.txt "dependencies of multizaehlen.py"): 
  dependencies of multizaehlen.py

* [menu_multizaehlen.exe](https://github.com/GuenterPartosch/Counting_texts/blob/master/multizaehlen/menu_multizaehlen.exe "Windows executables of menu_multizaehlen.py"): 
  Windows executables of menu_multizaehlen.py
* [menu_multizaehlen.py](https://github.com/GuenterPartosch/Counting_texts/blob/master/multizaehlen/menu_multizaehlen.py "Python program (menu variant for multizaehlen.py)"): 
  Python program (menu variant for multizaehlen.py)
* [menu_multizaehlen_ini.py](https://github.com/GuenterPartosch/Counting_texts/blob/master/multizaehlen/menu_multizaehlen_ini.py "configuration file for menu_multizaehlen.py"): 
  configuration file for menu_multizaehlen.py
  specification file for menu_multizaehlen.exe
* [menu_multizaehlen-dependencies.txt](https://github.com/GuenterPartosch/Counting_texts/blob/master/multizaehlen/menu_multizaehlen-dependencies.txt "dependencies of menu_multizaehlen.py"): 
  dependencies of menu_multizaehlen.py
