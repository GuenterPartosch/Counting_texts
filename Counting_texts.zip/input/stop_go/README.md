﻿# Overview

* [de-maerchen.txt](./de-maerchen.txt  "list with frequent words in german tales"): 
    list with frequent words in german tales
* [de-stop.txt](./de-stop.txt "list with frequent words in german texts"): 
    list with frequent words in german texts
* [de-trivial.txt](./de-trivial.txt "2nd list with trivial words in german texts"): 
    2nd list with trivial words in german texts
* [en-trivial.txt](./en-trivial.txt "list with trivial words in english texts"): 
    list with trivial words in english texts
* [fr-trivial.txt](./fr-trivial.txt "list with trivial words in french texts"): 
    list with trivial words in french texts
