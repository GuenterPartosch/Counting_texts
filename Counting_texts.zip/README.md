# Counting_texts

Counts "words" and characters in one or many texts.

## Folder input

* [input](./input "example texts; stop lists / go lists"): example texts; stop lists / go lists

## Folder multizaehlen

* [multizaehlen](./multizaehlen "programs and informations for multizaehlen.py (couting and comparing)"): programs and informations for multizaehlen.py (couting and comparing)
   
## Folder zaehlen

* [zaehlen](./zaehlen "programs and informations for zaehlen.py"): programs and informations for zaehlen.py
 
