# Counting_texts

Counts "words" and characters in texts.

## Folder input

* [input](https://github.com/GuenterPartosch/Counting_texts/tree/master/input "example texts; stop lists / go lists"): 

## Folder multizaehlen

* [multizaehlen](https://github.com/GuenterPartosch/Counting_texts/tree/master/multizaehlen "programs and informations for multizaehlen.py (couting and comparing)"): 
   
## Folder zaehlen

* [zaehlen](https://github.com/GuenterPartosch/Counting_texts/tree/master/zaehlen "programs and informations for zaehlen.py"): 
 